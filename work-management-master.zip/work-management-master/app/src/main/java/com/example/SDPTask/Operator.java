package com.example.SDPTask;
public class Operator {
    public String fullName, userName, email;

    public Operator(){

    }

    public Operator(String fullName, String userName, String email) {
        this.fullName = fullName;
        this.userName = userName;
        this.email = email;
    }
}

